class Test:
	def func(self,x):
		print (x+x)
Obj = Test()
mytest = Obj.func 
n = 2
for i in range(n):
	mytest(i) 
