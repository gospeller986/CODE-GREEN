def kadane(arr):
    maximum = max(arr)
    if maximum < 0:
        return maximum
    max_so_far = 0
    max_ending_here = 0
    for i in arr:
        max_ending_here = max_ending_here + i
        max_ending_here = max(max_ending_here, 0)
        max_so_far = max(max_so_far, max_ending_here)
    return max_so_far
if __name__ == '__main__':
    arr = [-8, -3, -6, -2, -5, -4]
    print('The sum of contiguous sublist with the largest sum is', kadane(arr))