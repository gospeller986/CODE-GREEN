from collections import deque
s = 'geek'
d = deque(s)
d.append('y')
d.appendleft('h')
print (d)
d.pop() 
d.popleft() 
print (list(reversed(d)))
