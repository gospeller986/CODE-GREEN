from random import randintdef swap(nums, i, j):
    temp = nums[i]
    nums[i] = nums[j]
    nums[j] = temp
def partition(nums, left, right, pIndex):
    pivot = nums[pIndex]
    swap(nums, pIndex, right)
    pIndex = left
    for i in range(left, right):
        if nums[i] <= pivot:
            swap(nums, i, pIndex)
            pIndex = pIndex + 1
    swap(nums, pIndex, right)
    return pIndex
def quickSelect(nums, left, right, k):
    if left == right:
        return nums[left]
    pIndex = randint(left, right)
    pIndex = partition(nums, left, right, pIndex)
        return nums[k]
    elif k < pIndex:
        return quickSelect(nums, left, pIndex - 1, k)
    else:
        return quickSelect(nums, pIndex + 1, right, k)
if __name__ == '__main__':
    nums = [7, 4, 6, 3, 9, 1]
    k = 2
    print('k\'th smallest element is', quickSelect(nums, 0, len(nums) - 1, k - 1))