def countsort(A, k):
    freq = [0] * (k + 1)
    for i in A:
        freq[i] += 1
    index = 0
    for i in range(k + 1):
        while freq[i] > 0:
            A[index] = i
            index += 1
            freq[i] -= 1
if __name__ == '__main__':
    A = [4, 2, 10, 10, 1, 4, 2, 1, 10]
    k = 10
    countsort(A, k)
    print(A)