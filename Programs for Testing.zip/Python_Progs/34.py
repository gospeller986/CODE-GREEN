x,y = 3,5
x, y = y, x
print (x,y)