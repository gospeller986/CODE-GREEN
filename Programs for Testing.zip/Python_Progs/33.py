mydict = {'g':1,'e':1,'e':1,'k':1}
word = 'geeks'
for w in word:
	try:
		mydict[w] += 1
	except KeyError:
		mydict[w] = 1
print (mydict)
