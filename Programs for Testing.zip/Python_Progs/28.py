import sys
def kadaneNeg(arr):
    max_so_far = -sys.maxsize
    max_ending_here = 0
    for i in range(len(arr)):
        max_ending_here = max_ending_here + arr[i]
        max_ending_here = max(max_ending_here, arr[i])
        max_so_far = max(max_so_far, max_ending_here)
    return max_so_far
if __name__ == '__main__':
    arr = [-8, -3, -6, -2, -5, -4]
    print('The sum of contiguous sublist with the largest sum is', kadaneNeg(arr))